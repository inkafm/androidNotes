package com.simplemobiletools.notes.pro.models

data class TextHistoryItem(val start: Int, val before: CharSequence?, val after: CharSequence?)
