package com.simplemobiletools.notes.pro.fragments

import androidx.fragment.app.Fragment

abstract class NoteFragment : Fragment()
