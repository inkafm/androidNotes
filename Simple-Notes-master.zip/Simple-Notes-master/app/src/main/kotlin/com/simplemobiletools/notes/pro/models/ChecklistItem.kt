package com.simplemobiletools.notes.pro.models

data class ChecklistItem(val id: Int, var title: String, var isDone: Boolean)
