package com.simplemobiletools.notes.pro.interfaces

interface ChecklistItemsListener {
    fun refreshItems()

    fun saveChecklist()
}
